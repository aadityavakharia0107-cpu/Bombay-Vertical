"""
Parse a MahaRERA search-results page -> list of project stubs
(rera_id, name, detail_url, ...).

STATUS: STUB. Cannot be written until samples/search_results.html exists.
If DevTools shows results loading via a JSON/XHR endpoint, this file
gets replaced by a 10-line JSON reader — far better outcome.
"""
from bs4 import BeautifulSoup

def parse(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "lxml")
    raise NotImplementedError("Awaiting samples/search_results.html")
