"""SQLite -> static JSON for the frontend. Run after scraping."""
import json, pathlib
from db import connect

OUT = pathlib.Path(__file__).resolve().parent.parent / "data" / "projects.json"

def export():
    con = connect()
    rows = [dict(r) for r in con.execute(
        "SELECT * FROM projects WHERE lat IS NOT NULL"
    )]
    for r in rows:
        r["progress"] = [dict(p) for p in con.execute(
            "SELECT quarter, pct_work, pct_booked FROM progress_updates "
            "WHERE rera_id=? ORDER BY quarter", (r["rera_id"],)
        )]
    OUT.write_text(json.dumps(rows, ensure_ascii=False))
    print(f"Exported {len(rows)} projects -> {OUT}")

if __name__ == "__main__":
    export()
