"""Initialize SQLite DB from schema.sql. Run: python src/db.py"""
import sqlite3, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
DB   = ROOT / "data" / "bombay.db"

def connect():
    DB.parent.mkdir(exist_ok=True)
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init():
    con = connect()
    con.executescript((ROOT / "schema.sql").read_text())
    con.commit()
    print(f"DB ready: {DB}")

if __name__ == "__main__":
    init()
