"""
Rate-limited, resumable fetcher. Downloads raw HTML to data/raw/,
logs every URL in scrape_log. Parsing is a separate step — re-parsing
never re-downloads.

Usage (after parsers are written):
    python src/scraper.py search   # crawl search-result pages
    python src/scraper.py details  # fetch detail page per project
"""
import hashlib, pathlib, sys, time
from datetime import datetime, timezone

import requests

from db import connect

ROOT    = pathlib.Path(__file__).resolve().parent.parent
RAW     = ROOT / "data" / "raw"
DELAY_S = 2.5
HEADERS = {"User-Agent": "Mozilla/5.0 (research; contact in repo)"}

# TODO after samples arrive: real search URL / POST payload structure
BASE_SEARCH_URL = "REPLACE_AFTER_SAMPLES"

def raw_path(url: str) -> pathlib.Path:
    h = hashlib.sha1(url.encode()).hexdigest()[:16]
    return RAW / f"{h}.html"

def fetch(url: str, session: requests.Session, con) -> str | None:
    """Fetch with cache + log. Returns HTML or None on failure."""
    p = raw_path(url)
    if p.exists():
        return p.read_text(errors="ignore")
    try:
        r = session.get(url, headers=HEADERS, timeout=30)
        r.raise_for_status()
        RAW.mkdir(parents=True, exist_ok=True)
        p.write_text(r.text)
        con.execute(
            "INSERT OR REPLACE INTO scrape_log VALUES (?,?,?)",
            (url, "ok", datetime.now(timezone.utc).isoformat()),
        )
        con.commit()
        time.sleep(DELAY_S)
        return r.text
    except Exception as e:
        con.execute(
            "INSERT OR REPLACE INTO scrape_log VALUES (?,?,?)",
            (url, f"failed: {e}", datetime.now(timezone.utc).isoformat()),
        )
        con.commit()
        print(f"FAIL {url}: {e}", file=sys.stderr)
        time.sleep(DELAY_S * 2)
        return None

def crawl_search():
    raise NotImplementedError("Blocked on samples/search_results.html")

def crawl_details():
    raise NotImplementedError("Blocked on samples/project_detail.html")

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    {"search": crawl_search, "details": crawl_details}.get(
        cmd, lambda: print(__doc__)
    )()
