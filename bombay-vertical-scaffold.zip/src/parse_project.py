"""
Parse a MahaRERA project detail page -> full project dict matching
the projects table, plus list of progress_updates rows.

STATUS: STUB. Cannot be written until samples/project_detail.html
and samples/progress_page.html exist.
"""
from bs4 import BeautifulSoup

def parse(html: str) -> tuple[dict, list[dict]]:
    soup = BeautifulSoup(html, "lxml")
    raise NotImplementedError("Awaiting samples/project_detail.html")
