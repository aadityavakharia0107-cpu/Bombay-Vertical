# Required samples — the entire project is blocked on this folder

From maharera.maharashtra.gov.in (project search portal), save via
Ctrl+S -> "Webpage, HTML Only", named exactly:

1. search_results.html  — one results page, filtered to Mumbai City district
2. project_detail.html  — detail page of any Worli/Lower Parel project
3. progress_page.html   — that project's quarterly progress / form filings tab

ALSO (most important): open DevTools (F12) -> Network tab -> filter XHR
BEFORE clicking Search. If results arrive as a JSON response:
4. Save that request URL + a copy of the JSON response as search_api.json
   A JSON endpoint makes parsers trivial and 5x more robust than HTML.

Upload all files to the chat.
