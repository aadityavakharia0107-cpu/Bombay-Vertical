-- Bombay Vertical core schema
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS projects (
  rera_id        TEXT PRIMARY KEY,        -- e.g. P51900000123
  name           TEXT NOT NULL,
  developer      TEXT,
  locality       TEXT,
  district       TEXT,
  address        TEXT,
  project_type   TEXT,                    -- residential / commercial / mixed
  status         TEXT,                    -- registered / completed / lapsed / revoked
  start_date     TEXT,
  completion_eta TEXT,                    -- current promised date
  original_eta   TEXT,                    -- first promised date (extensions = eta drift)
  total_units    INTEGER,
  booked_units   INTEGER,
  total_buildings INTEGER,
  litigation     INTEGER DEFAULT 0,       -- bool: any litigation disclosed
  lat            REAL,
  lng            REAL,
  osm_footprint  TEXT,                    -- GeoJSON polygon, Phase 2
  detail_url     TEXT,
  scraped_at     TEXT
);

CREATE TABLE IF NOT EXISTS progress_updates (
  rera_id     TEXT REFERENCES projects(rera_id),
  quarter     TEXT,                       -- e.g. 2026-Q1
  pct_work    REAL,                       -- % construction complete as filed
  pct_booked  REAL,
  filed_at    TEXT,
  PRIMARY KEY (rera_id, quarter)
);

CREATE TABLE IF NOT EXISTS scrape_log (
  url        TEXT PRIMARY KEY,
  status     TEXT,                        -- ok / failed / parsed
  fetched_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_proj_locality ON projects(locality);
CREATE INDEX IF NOT EXISTS idx_proj_status   ON projects(status);
