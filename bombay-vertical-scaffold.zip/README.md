# Bombay Vertical — Phase 0 Scaffold

Pipeline: MahaRERA scraper -> SQLite -> JSON export -> map frontend.

## Setup
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python src/db.py                 # creates data/bombay.db from schema.sql
```

## Status
- [x] Schema
- [x] Scraper engine (rate-limited, resumable)
- [ ] Parsers — BLOCKED: need samples/ populated (see samples/README.md)
- [ ] Geocoder (Phase 2)
- [ ] JSON exporter -> frontend

## Rules
- 1 request / 2.5 s minimum. Never hammer MahaRERA.
- Scraper writes raw HTML to data/raw/ first, parses second.
  Re-parsing never re-downloads.
